#include "predator.hpp"
// пока ничего дополнительно
