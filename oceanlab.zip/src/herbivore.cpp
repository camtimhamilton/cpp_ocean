#include "herbivore.hpp"
// здесь пока пусто
